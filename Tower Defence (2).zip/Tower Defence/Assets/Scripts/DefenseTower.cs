using UnityEngine;

public class DefenseTower : MonoBehaviour
{
    public float range = 5f;
    public float fireRate = 1f;
    public GameObject bulletPrefab;
    public Transform firePoint;

    private float fireCooldown = 0f;

    public AudioSource fireSource;

    void Update()
    {
        fireCooldown -= Time.deltaTime;

        GameObject target = FindClosestEnemy();
        if (target != null && fireCooldown <= 0f)
        {
            Shoot(target);
            fireCooldown = 2f / fireRate;
        }
    }

    GameObject FindClosestEnemy()
    {
        GameObject[] enemies = GameObject.FindGameObjectsWithTag("Enemy");
        GameObject closest = null;
        float minDist = Mathf.Infinity;

        foreach (GameObject enemy in enemies)
        {
            float dist = Vector3.Distance(transform.position, enemy.transform.position);
            if (dist < minDist && dist <= range)
            {
                closest = enemy;
                minDist = dist;
            }
        }
        return closest;
    }

    void Shoot(GameObject target)
    {
        fireSource.Play();
        
        GameObject bullet = Instantiate(bulletPrefab, firePoint.position, Quaternion.identity);
        bullet.GetComponent<Bullet>().Init(target.transform);
    }
}