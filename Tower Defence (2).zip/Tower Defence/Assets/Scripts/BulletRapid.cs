using UnityEngine;

public class BulletRapid : MonoBehaviour
{
    private Transform target;
    private float damage;
    public float speed = 15f;

    public void SetTarget(Transform newTarget, int dmg)
    {
        target = newTarget;
        damage = dmg;
    }

    void Update()
    {
        if (target == null)
        {
            Destroy(gameObject);
            return;
        }

        // Move toward target
        Vector3 direction = target.position - transform.position;
        float distanceThisFrame = speed * Time.deltaTime;

        if (direction.magnitude <= distanceThisFrame)
        {
            HitTarget();
            return;
        }

        transform.Translate(direction.normalized * distanceThisFrame, Space.World);
        transform.LookAt(target);
    }

    void HitTarget()
    {
        // Deal damage to enemy
        EnemyHealth enemy = target.GetComponent<EnemyHealth>();
        if (enemy != null)
        {
            enemy.TakeDamage((int)damage);
        }

        Destroy(gameObject);
    }
}
