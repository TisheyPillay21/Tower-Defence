using UnityEngine;

public class BuildManager : MonoBehaviour
{
    public static BuildManager instance;
    private BuildSpot currentSpot;

    public float messageTimer = 5f;
    public GameObject messagePanel;
    private bool messageBool;

    [Header("Tower Prefabs")]
    public GameObject basicTowerPrefab;
    public GameObject AOETowerPrefab;
    public GameObject rapidFireTowerPrefab;

    [Header("UI Panel")]
    public GameObject towerSelectPanel;

    private void Awake()
    {
        if (instance == null) instance = this;
        else Destroy(gameObject);

        towerSelectPanel.SetActive(false);
    }

    private void Update()
    {
        if (messageBool == true)
        {
            messagePanel.SetActive(true);
            messageTimer -= Time.deltaTime;

            if (messageTimer <= 0)
            {
                messagePanel.SetActive(false);
                messageTimer = 5f;
                messageBool = false;
            }
        }
    }

    public void OpenTowerSelection(BuildSpot spot)
    {
        currentSpot = spot;
        towerSelectPanel.SetActive(true);
    }

    public void CloseTowerSelection()
    {
        towerSelectPanel.SetActive(false);
        currentSpot = null;
    }

    public void SelectTower(int towerIndex)
    {
        if (currentSpot == null) return;

        GameObject selectedTower = null;

        switch (towerIndex)
        {
            case 0:
                selectedTower = basicTowerPrefab;
                break;
            case 1:
                selectedTower = AOETowerPrefab;
                break;
            case 2:
                selectedTower = rapidFireTowerPrefab;
                break;
        }

        if (selectedTower != null)
        {
            if (towerIndex == 0)
            {
                if (UIController.shields >= 10)
                {
                    currentSpot.BuildTower(selectedTower);
                    CloseTowerSelection();
                    UIController.shields -= 10;
                }
                else
                {
                    messageBool = true;
                    CloseTowerSelection();
                    
                }
            }

            if (towerIndex == 2)
            {
                if (UIController.shields >= 20)
                {
                    currentSpot.BuildTower(selectedTower);
                    CloseTowerSelection();
                    UIController.shields -= 20;
                }
                else
                {
                    messageBool = true;
                    CloseTowerSelection();
                }
            }

            if (towerIndex == 1)
            {
                if (UIController.shields >= 50)
                {
                    currentSpot.BuildTower(selectedTower);
                    CloseTowerSelection();
                    UIController.shields -= 50;
                }
                else
                {
                    messageBool = true;
                    CloseTowerSelection();
                }
            }

        }
    }
}