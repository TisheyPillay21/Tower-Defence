using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.EventSystems;

public class BuildSpot : MonoBehaviour
{
    public bool isOccupied = false;

    private void OnMouseDown()
    {
        if (isOccupied) return;

        // Ignore if clicking over UI (so you don�t build while clicking UI buttons)
        if (UnityEngine.EventSystems.EventSystem.current.IsPointerOverGameObject()) return;

        if (BuildManager.instance != null)
            BuildManager.instance.OpenTowerSelection(this);
    }

    public void BuildTower(GameObject towerPrefab)
    {
        if (isOccupied || towerPrefab == null) return;

        Instantiate(towerPrefab, transform.position + Vector3.up * 0.5f, Quaternion.Euler(-90, 0, 0));
        isOccupied = true;
    }
}