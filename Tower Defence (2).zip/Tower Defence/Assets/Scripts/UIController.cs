using System;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

public class UIController : MonoBehaviour
{
    public GameObject pausePanel;
    public GameObject gameOverPanel;

    public TextMeshProUGUI towerHealth;
    public TextMeshProUGUI shieldsText;

    public TextMeshProUGUI waveText;
    public TextMeshProUGUI waveTimerText;

    public static int shields = 10;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        shields = 10;
    }

    // Update is called once per frame
    void Update()
    {
        towerHealth.text = Convert.ToString(Tower.health);
        shieldsText.text = Convert.ToString(shields);

        if (Tower.health <= 0 )
        {
            Time.timeScale = 0;
            gameOverPanel.SetActive(true);
        }
    }

    public void OnStartClick()
    {
        SceneManager.LoadSceneAsync("SampleScene");
        Time.timeScale = 1;
    }

    public void OnExitClick()
    {
        Application.Quit();
    }

    public void OnPauseClick()
    {
        Time.timeScale = 0;
        pausePanel.SetActive(true);
    }

    public void OnResumeClick()
    {
        Time.timeScale = 1;
        pausePanel.SetActive(false);
    }

    public void OnRestartClick()
    {
        SceneManager.LoadSceneAsync("SampleScene");
        Time.timeScale = 1;

    }

    public void OnMainMenuClick()
    {
        SceneManager.LoadSceneAsync("StartScene");
    }

    public void UpdateWaveUI(int waveNumber)
    {
        if (waveText != null)
            waveText.text = $"{waveNumber}";
    }

    public void UpdateWaveTimer(float time)
    {
        if (waveTimerText != null)
            waveTimerText.text = $"{Mathf.CeilToInt(time)} Seconds";
    }
}
