using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WFCTerrainGenerator : MonoBehaviour
{
    [Header("Grid")]
    public int gridWidth = 24;
    public int gridHeight = 24;
    public float tileSize = 1f;          

    [Header("Prefabs {0=ground, 1=path}")]
    public GameObject[] tilePrefabs;     // [0]=ground, [1]=path
    public GameObject towerPrefab;

    [Header("Enemies")]
    public EnemyType[] enemyTypes;

    [Header("Wave Settings")]
    public float timeBetweenWaves = 5f;
    public float spawnInterval = 1f;
    public int enemiesPerWave = 5;

    private int currentWave = 0;
    private bool spawning = false;

    [Header("Gameplay")]
    public int numberOfPaths = 3;
    public float groundYOffset = -0.01f; 
    public float enemyY = 0.5f;          // keep enemies slightly above tiles
    public float spawnEvery = 2.5f;

    [Header("Tower Placement")]
    public GameObject buildSpotPrefab;   // Marker prefab 
    public int numberOfBuildSpots = 5;
    public Vector2Int towerPos;

    private List<Vector3> buildSpots = new List<Vector3>();

    int[,] grid;                        // 0=ground, 1=path
    readonly List<List<Vector3>> paths = new List<List<Vector3>>();
    Vector3 towerWorldPos;

    public UIController uiController;

    void Start()
    {
        GenerateTerrain();
        PlaceBuildSpots();
        PlaceTower();
        StartCoroutine(WaveSpawner());
    }

    void GenerateTerrain()
    {
        // clear old tiles if we regenerate in play mode
        foreach (Transform c in transform) { Destroy(c.gameObject); }

        grid = new int[gridWidth, gridHeight];
        paths.Clear();

        // fill ground
        for (int x = 0; x < gridWidth; x++)
            for (int z = 0; z < gridHeight; z++)
                grid[x, z] = 0;

        // tower cell (center)
        int targetX = gridWidth / 2;
        int targetZ = gridHeight / 2;
        grid[targetX, targetZ] = 1;
        towerWorldPos = ToWorld(targetX, targetZ);

        // carve randomized paths that all end at the tower
        HashSet<int> usedStarts = new HashSet<int>();
        System.Random rng = new System.Random();

        for (int p = 0; p < numberOfPaths; p++)
        {
            // ensure unique start X on top edge
            int startX;
            do { startX = rng.Next(0, gridWidth); } while (!usedStarts.Add(startX));
            int x = startX;
            int z = 0;

            List<Vector3> currentPath = new List<Vector3>();
            Vector3 lastAdded = new Vector3(float.NaN, 0, 0);

            // walk step-by-step toward the tower with some randomness
            while (x != targetX || z != targetZ)
            {
                grid[x, z] = 1;

                Vector3 wp = ToWorld(x, z);
                if (wp != lastAdded) { currentPath.Add(new Vector3(wp.x, enemyY, wp.z)); lastAdded = wp; }

                // 70% move toward target, 30% detour (still biased forward)
                if (UnityEngine.Random.value < 0.7f)
                {
                    // randomly choose which axis to resolve first this step
                    if (UnityEngine.Random.value < 0.5f)
                    {
                        // horizontal first
                        if (x < targetX) x++;
                        else if (x > targetX) x--;
                        else if (z < targetZ) z++;
                        else if (z > targetZ) z--;
                    }
                    else
                    {
                        // vertical first
                        if (z < targetZ) z++;
                        else if (z > targetZ) z--;
                        else if (x < targetX) x++;
                        else if (x > targetX) x--;
                    }
                }
                else
                {
                    // small detour that still trends "forward"
                    int dir = rng.Next(0, 3);
                    if (dir == 0 && x > 0) x--;                             // left
                    else if (dir == 1 && x < gridWidth - 1) x++;            // right
                    else if (dir == 2 && z < gridHeight - 1) z++;           // down (toward center from top)
                }
            }

            // ensure last waypoint is tower
            currentPath.Add(new Vector3(towerWorldPos.x, enemyY, towerWorldPos.z));
            paths.Add(currentPath);
        }

        // instantiate tiles (one per cell)
        for (int x = 0; x < gridWidth; x++)
        {
            for (int z = 0; z < gridHeight; z++)
            {
                Vector3 pos = ToWorld(x, z);
                if (grid[x, z] == 1)
                    Instantiate(tilePrefabs[1], pos, Quaternion.Euler(-90, 0, 0), transform);                     // path
                else
                    Instantiate(tilePrefabs[Random.Range(2, tilePrefabs.Length)], pos + Vector3.up * groundYOffset, Quaternion.Euler(-90, 0, 0), transform); // ground
            }
        }
    }

    void PlaceBuildSpots()
    {
        buildSpots.Clear();
        HashSet<Vector2Int> candidateTiles = new HashSet<Vector2Int>();

        // loop through tiles in a square around the tower
        for (int x = towerPos.x - 1; x <= towerPos.x + 1; x++)
        {
            for (int z = towerPos.y - 1; z <= towerPos.y + 1; z++)
            {
                if (x >= 0 && x < gridWidth && z >= 0 && z < gridHeight)
                {
                    // distance from tower
                    int dist = Mathf.Abs(x - towerPos.x) + Mathf.Abs(z - towerPos.y);

                    if (dist >= 1 && dist <= 3) // only 1 tile away
                    {
                        if (grid[x, z] == 0) // ground tile only
                        {
                            candidateTiles.Add(new Vector2Int(x, z));
                        }
                    }
                }
            }
        }

        // random selection of spots
        List<Vector2Int> candidates = new List<Vector2Int>(candidateTiles);

        int spotsToPlace = Mathf.Min(numberOfBuildSpots, candidates.Count);
        for (int i = 0; i < spotsToPlace; i++)
        {
            int index = Random.Range(0, candidates.Count);
            Vector2Int chosen = candidates[index];
            candidates.RemoveAt(index);

            Vector3 pos = new Vector3(chosen.x * tileSize, 0, chosen.y * tileSize);
            buildSpots.Add(pos);
            Instantiate(buildSpotPrefab, pos + Vector3.up * 0.1f, Quaternion.Euler(-90, 0, 0), transform);
        }
    }

    void PlaceTower()
    {
        if (towerPrefab == null) return;
        var tower = Instantiate(towerPrefab, towerWorldPos + Vector3.up * (enemyY - 0.5f), Quaternion.Euler(-90, 0, 0));
        var playerBase = tower.AddComponent<Tower>();
        playerBase.Initialize(100);
        //towerPos = new Vector2Int((int)towerWorldPos.x, (int)towerWorldPos.z);
    }

    void SpawnEnemyWithProgression()
    {
        if (paths.Count == 0 || enemyTypes.Length == 0) return;

        // pick random path
        int randomPathIndex = Random.Range(0, paths.Count);
        List<Vector3> chosenPath = paths[randomPathIndex];

        // --- Calculate enemy type probabilities ---
        float normalChance = Mathf.Clamp01(1f - (currentWave * 0.05f)); // starts high, decreases
        float defensiveChance = Mathf.Clamp01((currentWave * 0.03f));   // grows slowly
        float powerfulChance = Mathf.Clamp01((currentWave * 0.02f));    // grows slower

        // normalize total (so chances always sum to 1)
        float total = normalChance + defensiveChance + powerfulChance;
        normalChance /= total;
        defensiveChance /= total;
        powerfulChance /= total;

        // random selection
        float roll = Random.value;
        EnemyType chosenType;

        if (roll < normalChance)
            chosenType = enemyTypes[0]; // Normal
        else if (roll < normalChance + defensiveChance)
            chosenType = enemyTypes[1]; // Defensive
        else
            chosenType = enemyTypes[2]; // Powerful

        // spawn enemy
        GameObject enemy = Instantiate(chosenType.prefab);
        var follow = enemy.GetComponent<EnemyFollowPath>();
        if (follow == null) follow = enemy.AddComponent<EnemyFollowPath>();
        follow.Initialize(chosenPath, towerWorldPos + Vector3.up * enemyY);
        follow.speed = chosenType.speed;

        var hp = enemy.GetComponent<EnemyHealth>();
        if (hp == null) hp = enemy.AddComponent<EnemyHealth>();
        hp.health = chosenType.health;

        var enemyCore = enemy.GetComponent<Enemy>();
        if (enemyCore == null) enemyCore = enemy.AddComponent<Enemy>();
        enemyCore.damage = chosenType.damage;
    }

    private IEnumerator WaveSpawner()
    {
        yield return new WaitForSeconds(2f); // short delay before starting

        while (true)
        {
            currentWave++;
            spawning = true;

            // ? Update UI when wave starts
            if (uiController != null)
                uiController.UpdateWaveUI(currentWave);

            Debug.Log($"Starting Wave {currentWave}");

            int enemyCount = enemiesPerWave + (currentWave * 2);
            float currentSpawnInterval = Mathf.Max(0.3f, spawnInterval - (currentWave * 0.05f));

            // Spawn enemies for this wave
            for (int i = 0; i < enemyCount; i++)
            {
                SpawnEnemyWithProgression();
                yield return new WaitForSeconds(currentSpawnInterval);
            }

            spawning = false;

            // Wait before next wave, updating countdown each second
            float countdown = timeBetweenWaves;
            while (countdown > 0f)
            {
                if (uiController != null)
                    uiController.UpdateWaveTimer(countdown);

                countdown -= Time.deltaTime;
                yield return null;
            }

            if (uiController != null)
                uiController.UpdateWaveTimer(0f);
        }
    }

    Vector3 ToWorld(int x, int z)
    {
        return transform.position + new Vector3(x * tileSize, 0f, z * tileSize);
    }

#if UNITY_EDITOR
    // visualise paths in the Scene view
    void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.yellow;
        foreach (var path in paths)
        {
            for (int i = 0; i < path.Count - 1; i++)
                Gizmos.DrawLine(path[i], path[i + 1]);
        }
        Gizmos.color = Color.cyan;
        Gizmos.DrawWireSphere(towerWorldPos + Vector3.up * enemyY, 0.25f);
    }
#endif
}