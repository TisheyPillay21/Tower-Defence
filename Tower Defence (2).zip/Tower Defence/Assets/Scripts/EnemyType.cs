using UnityEngine;

[System.Serializable]
public class EnemyType
{
    public string name;
    public GameObject prefab;
    public float speed = 2f;
    public int health = 5;
    public int damage = 1;
}