using UnityEngine;
using System.Collections.Generic;

public class AOETower : MonoBehaviour
{
    [Header("Tower Settings")]
    public float attackRange = 5f;
    public float attackCooldown = 3f;
    public int damage = 2;
    public float stunDuration = 2f;

    [Header("Effects")]
    public ParticleSystem aoeEffect; // optional VFX for the attack

    private float cooldownTimer;

    public AudioSource fireSource;

    void Update()
    {
        cooldownTimer -= Time.deltaTime;

        if (cooldownTimer <= 0f)
        {
            AttackAOE();
            cooldownTimer = attackCooldown;
        }
    }

    void AttackAOE()
    {
        Collider[] hits = Physics.OverlapSphere(transform.position, attackRange);

        foreach (Collider hit in hits)
        {
            if (hit.CompareTag("Enemy"))
            {
                EnemyHealth enemyHealth = hit.GetComponent<EnemyHealth>();
                Enemy enemy = hit.GetComponent<Enemy>();
                if (enemy != null)
                {
                    fireSource.Play();

                    enemyHealth.TakeDamage(damage);
                    enemy.Stun(stunDuration);
                }
            }
        }

        if (aoeEffect != null)
            aoeEffect.Play();
    }

    void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.cyan;
        Gizmos.DrawWireSphere(transform.position, attackRange);
    }
}