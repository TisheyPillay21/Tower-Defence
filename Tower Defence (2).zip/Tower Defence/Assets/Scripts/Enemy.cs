using System.Collections.Generic;
using System.IO;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    private List<Vector3> path;
    private int currentIndex = 0;
    public float speed = 2f;
    private int health = 5;
    public int damage = 1;

    private bool isStunned = false;
    private float stunTimer = 0f;

    public void Initialize(List<Vector3> assignedPath)
    {
        path = assignedPath;
        transform.position = path[0];
    }

    void Update()
    {
        if (isStunned)
        {
            stunTimer -= Time.deltaTime;
            if (stunTimer <= 0f) isStunned = false;
            return;
        }

        if (path == null || currentIndex >= path.Count) return;

        Vector3 targetPos = path[currentIndex];
        Vector3 moveDir = targetPos - transform.position;

        if (moveDir.sqrMagnitude > 0.001f)
        {
            Vector3 direction = moveDir.normalized;
            transform.position += direction * speed * Time.deltaTime;

            Quaternion targetRot = Quaternion.LookRotation(direction, Vector3.up);
            transform.rotation = Quaternion.Slerp(transform.rotation, targetRot, Time.deltaTime * 5f);
        }

        if (Vector3.Distance(transform.position, targetPos) < 0.3f)
            currentIndex++;

        if (stunTimer <= 0f)
        {
            isStunned = false;
            Renderer r = GetComponentInChildren<Renderer>();
            if (r != null) r.material.color = Color.white;
        }
    }

    public void TakeDamage(int dmg)
    {
        health -= dmg;
        if (health <= 0) Die();
    }

    private void Die()
    {
        Destroy(gameObject);
    }

    public void Stun(float duration)
    {
        if (!isStunned)
        {
            // Optional: change color to indicate stun
            Renderer r = GetComponentInChildren<Renderer>();
            if (r != null) r.material.color = Color.cyan;
        }

        isStunned = true;
        stunTimer = duration;
    }
}