using System.Collections.Generic;
using UnityEngine;

public class Tower : MonoBehaviour
{
    public static int health;

    public AudioSource towerHit;

    public void Initialize(int startHealth)
    {
        health = startHealth;
    }

    public void TakeDamage(int dmg)
    {
        health -= dmg;
        Debug.Log("Tower Health: " + health);
        if (health <= 0)
        {
            Debug.Log("Game Over! Tower destroyed.");
            Destroy(gameObject);
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Enemy"))
        {
            Enemy enemy = other.GetComponent<Enemy>();
            if (enemy != null)
            {
                towerHit.Play();
                TakeDamage(enemy.damage);
            }

            Destroy(other.gameObject); // remove the enemy
        }
    }
}