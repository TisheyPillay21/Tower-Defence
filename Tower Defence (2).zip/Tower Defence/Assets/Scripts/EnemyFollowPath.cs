using System.Collections.Generic;
using UnityEngine;

public class EnemyFollowPath : MonoBehaviour
{
    public float speed = 2.5f;
    public float reachThreshold = 0.05f;

    List<Vector3> waypoints;
    int i;
    Vector3 finalTarget;

    public void Initialize(List<Vector3> path, Vector3 towerPos)
    {
        waypoints = new List<Vector3>(path);
        finalTarget = towerPos;
        i = 0;

        if (waypoints.Count > 0)
            transform.position = waypoints[0];
        else
            transform.position = finalTarget;
    }

    void Update()
    {
        if (waypoints == null || waypoints.Count == 0)
        {
            MoveTowards(finalTarget);
            return;
        }

        // move towards current waypoint
        Vector3 target = waypoints[i];
        MoveTowards(target);

        // reached this waypoint?
        if ((transform.position - target).sqrMagnitude <= reachThreshold * reachThreshold)
        {
            i++;
            if (i >= waypoints.Count)
            {
                // finished the path; head to final target (tower center)
                waypoints.Clear();
            }
        }
    }

    void MoveTowards(Vector3 target)
    {
        Vector3 pos = transform.position;
        // keep constant Y so we don't drift vertically
        target.y = pos.y;
        transform.position = Vector3.MoveTowards(pos, target, speed * Time.deltaTime);
    }
}
