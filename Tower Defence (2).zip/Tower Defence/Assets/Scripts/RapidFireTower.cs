using UnityEngine;
using System.Collections.Generic;

public class RapidFireTower : MonoBehaviour
{
    [Header("Tower Settings")]
    public float range = 6f;
    public float fireRate = 0.2f;
    public int damage = 1;

   [Header("References")]
    public GameObject bulletPrefab;
    public Transform firePoint;

    private float fireCooldown;
    private Transform target;

    public AudioSource fireSource;

    void Update()
    {
        FindTarget();
        HandleShooting();
    }

    void FindTarget()
    {
        Collider[] hits = Physics.OverlapSphere(transform.position, range);
        float closestDist = Mathf.Infinity;
        target = null;

        foreach (Collider hit in hits)
        {
            if (hit.CompareTag("Enemy"))
            {
                float dist = Vector3.Distance(transform.position, hit.transform.position);
                if (dist < closestDist)
                {
                    closestDist = dist;
                    target = hit.transform;
                }
            }
        }
    }

    void HandleShooting()
    {
        if (target == null) return;

        //transform.LookAt(target);

        fireCooldown -= Time.deltaTime;
        if (fireCooldown <= 0f)
        {
            Shoot();
            fireCooldown = fireRate;
        }
    }

    void Shoot()
    {
        if (bulletPrefab == null || firePoint == null) return;

        fireSource.Play();

        GameObject bullet = Instantiate(bulletPrefab, firePoint.position, Quaternion.identity);
        BulletRapid bulletScript = bullet.GetComponent<BulletRapid>();
        bulletScript.SetTarget(target, damage);
    }

    void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, range);
    }
}